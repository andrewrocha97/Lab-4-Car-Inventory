﻿Public Class Cars

    Private Shared carCount As Integer ' Shared private variable - number of cars '
    Private carIdNumber As Integer = 0 ' Private variable - car's ID number '
    Private carMake As String = String.Empty ' Private variable - car make '
    Private carModel As String = String.Empty ' Private variable - car model '
    Private carYear As String = String.Empty ' Private variable - car year '
    Private carPrice As Double = 0.0 ' Private variable - car price '
    Private carNew As Boolean = False ' Private variable - is the car new or not '

    Public Sub New()

        ' Increment shared variable counter by one '
        carCount += 1
        ' Assign car's ID number '
        carIdNumber = carCount

    End Sub

    Public Sub New(make As String, model As String, year As String, price As Double, newCar As Boolean)

        ' Call the other constructor '
        Me.New()

        ' Set all variables '
        carMake = make
        carModel = model
        carYear = year
        carPrice = price
        carNew = newCar
    End Sub

    Public ReadOnly Property Count() As Integer
        ' Get number of cars instantiated '
        Get
            Return carCount
        End Get
    End Property

    Public ReadOnly Property IdNumber() As Integer
        ' Gets car ID number '
        Get
            Return carIdNumber
        End Get
    End Property

    Public Property NewCar() As Boolean
        ' Get and set if car is new status '
        Get
            Return carNew
        End Get
        Set(ByVal value As Boolean)
            carNew = value
        End Set
    End Property

    Public Property MakeOfCar() As String
        ' Get and sets make of the car '
        Get
            Return carMake
        End Get
        Set(ByVal value As String)
            carMake = value
        End Set
    End Property

    Public Property ModelOfCar() As String
        ' Get and sets model of the car '
        Get
            Return carModel
        End Get
        Set(ByVal value As String)
            carModel = value
        End Set
    End Property

    Public Property YearOfCar() As String
        ' Get and sets year of the car '
        Get
            Return carYear
        End Get
        Set(ByVal value As String)
            carYear = value
        End Set
    End Property

    Public Property PriceOfCar() As Double
        ' Get and sets price of the car '
        Get
            Return carPrice
        End Get
        Set(ByVal value As Double)
            carPrice = value
        End Set
    End Property
    ' Function to get description of the car based on the private properties within the class scope '
    Public Function GetDescription() As String

        Dim carStatus As String = String.Empty

        If carNew = True Then
            carStatus = "new"
        Else
            carStatus = "used"
        End If

        Return "This car is a " & carYear & " " & carMake & " " & carModel & ". It is worth " & carPrice.ToString("C") & " and is a " & carStatus & " car."

    End Function
End Class
