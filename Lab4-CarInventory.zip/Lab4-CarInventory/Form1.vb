﻿'Name:          Andrew Rocha
'ID:            100590342
'Date Created:  March 15th, 2019
'Purpose:       Lab 4 - Car Inventory
'Description:   You are being asked to create a car inventory application for a new client.
'               The good news Is the tech lead had created a similar application For another
'               client, so you can use the old application As the basis For the New application
'               (CustomerList). The old application maintains a list Of customers, While the
'               New application will maintain the current inventory For a car lot. 
'

Option Strict On

Public Class frmCarInventory

    Private carList As New SortedList ' Collection of all the carList in the list '
    Private currentCarIdNumber As String = String.Empty ' The current selected car ID number '
    Private editMode As Boolean = False ' Declare edit flag as false '

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        ' Ends the program '
        Application.Exit()

    End Sub
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        ' Calls function to reset the controls back to default state '
        Reset()

    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        Dim car As Cars ' Declare Cars class '
        Dim carItem As ListViewItem ' Declare ListViewItem class '

        ' Check if user input is correct by validating '
        If Validation() = True Then

            ' Set the edit flag to true '
            editMode = True

            ' Prompt user that the information entered, is correct '
            lblResult.Text = "It WORKS!"

            ' Check if current car ID number has no value '
            If currentCarIdNumber.Trim.Length = 0 Then

                ' Create new car object using parameterized constructor '
                car = New Cars(cmbMake.Text, txtModel.Text, cmbYear.Text, Convert.ToDouble(txtPrice.Text), chkNew.Checked)

                ' Add the new car to the car list '
                carList.Add(car.IdNumber.ToString(), car)

            Else
                ' Get car from the car list collection '
                car = CType(carList.Item(currentCarIdNumber), Cars)

                ' Update data in the specific object from controls '
                car.MakeOfCar = cmbMake.Text
                car.ModelOfCar = txtModel.Text
                car.YearOfCar = cmbYear.Text
                car.PriceOfCar = Convert.ToDouble(txtPrice.Text)
                car.NewCar = chkNew.Checked
            End If

            ' Clear items from listview '
            lvwCarInventory.Items.Clear()

            ' Loop through car list to populate list view '
            For Each carEntry As DictionaryEntry In carList

                ' Star a new ListViewItem '
                carItem = New ListViewItem()

                ' Get car from the list  '
                car = CType(carEntry.Value, Cars)

                ' Assign values to the checked control and subitems '
                carItem.Checked = car.NewCar
                carItem.SubItems.Add(car.IdNumber.ToString())
                carItem.SubItems.Add(car.MakeOfCar)
                carItem.SubItems.Add(car.ModelOfCar)
                carItem.SubItems.Add(car.YearOfCar)
                carItem.SubItems.Add(car.PriceOfCar.ToString("C"))

                ' Add new instantiated and populated ListViewItem to listview control '
                lvwCarInventory.Items.Add(carItem)

            Next carEntry
            ' Calls function to reset the controls to default state '
            Reset()

            ' Set edit flag to false '
            editMode = False
        End If

    End Sub
    Private Sub Reset()
        ' Function for resetting controls back to default state '
        cmbMake.SelectedIndex = -1
        txtModel.Text = String.Empty
        cmbYear.SelectedIndex = -1
        txtPrice.Text = String.Empty
        chkNew.Checked = False

        currentCarIdNumber = String.Empty

        cmbMake.Focus()

    End Sub
    ' Function for validation '
    Private Function Validation() As Boolean

        Dim returnValue As Boolean = True ' 
        Dim output As String = String.Empty ' Output error messages '
        Dim userPrice As Double ' User entered price '
        ' Constant '
        Const MINIMUM_PRICE As Double = 0.0 ' Minimum price user must enter '

        ' Check if user selected a Make '
        If cmbMake.SelectedIndex = -1 Then

            ' Add error message to output '
            output += "Please select make of the car." & vbCrLf

            ' Set return value to false '
            returnValue = False

        End If

        ' Check if user entered a Model in the textbox '
        If txtModel.Text.Trim.Length = 0 Then

            ' Add error message to output '
            output += "Please enter the model of the car." & vbCrLf

            ' Set return value to false '
            returnValue = False

        End If

        ' Check if user selected a Year '
        If cmbYear.SelectedIndex = -1 Then

            ' Add error message to output '
            output += "Please select year of the car." & vbCrLf

            ' Set return value to false '
            returnValue = False

        End If

        ' Check if user entered a Price in the textbox '
        If txtPrice.Text.Trim.Length = 0 Then

            ' Add error message to output '
            output += "Please enter the price of the car." & vbCrLf

            ' Set return value to false '
            returnValue = False
        Else

            ' Check if user entered a real number and if it within range '
            If (Double.TryParse(txtPrice.Text.Trim, userPrice) = False OrElse userPrice < MINIMUM_PRICE) Then

                ' Add error message to output '
                output += "The price of the car must be a real number and must be higher than " & MINIMUM_PRICE & "."

                ' Set return value to false '
                returnValue = False
            End If
        End If

        ' Check if any value did not validate '
        If returnValue = False Then

            ' Prompt user that there sre errors with their input '
            lblResult.Text = "Errors!" & vbCrLf & output
        End If

        ' Return boolean value '
        Return returnValue

    End Function

    Private Sub lvwCarInventory_ItemCheck(sender As Object, e As ItemCheckEventArgs) Handles lvwCarInventory.ItemCheck

        ' If edit flag is false '
        If editMode = False Then

            ' The new value to the current value '
            e.NewValue = e.CurrentValue

        End If
    End Sub

    Private Sub lvwCarInventory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwCarInventory.SelectedIndexChanged

        ' Constant representing the index of the subitem in the list that holds the car ID number '
        Const idSubItemIndex As Integer = 1

        ' Get the car ID number
        currentCarIdNumber = lvwCarInventory.Items(lvwCarInventory.FocusedItem.Index).SubItems(idSubItemIndex).Text

        ' Use car ID number to get car from the collection object '
        Dim car As Cars = CType(carList.Item(currentCarIdNumber), Cars)

        ' Set controls on the form '
        cmbMake.Text = car.MakeOfCar
        txtModel.Text = car.ModelOfCar
        cmbYear.Text = car.YearOfCar
        txtPrice.Text = Convert.ToString(car.PriceOfCar)
        chkNew.Checked = car.NewCar

        lblResult.Text = car.GetDescription()

    End Sub
End Class
